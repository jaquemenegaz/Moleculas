$(document).ready(function() {
    //const elements = { elements | tojson };
    const elementContainer = $('#elements');

    // Adiciona os elementos como checkboxes
    /*elements.forEach(element => {
        const checkbox = `
            <div class="form-check">
                <input type="checkbox" class="form-check-input" id="${element.symbol}" data-valence="${element.valence}">
                <label class="form-check-label" for="${element.symbol}">${element.name} (${element.symbol})</label>
            </div>
        `;
        elementContainer.append(checkbox);
    });*/

    // Calcula a camada de valência total ao clicar no botão
    $('#combine').click(function() {
        const selectedElements = [];

        $('input:checked').each(function() {
            const element = {
                name: $(this).siblings('label').text(),
                valence: parseInt($(this).data('valence'))
            };
            selectedElements.push(element);
        });

        const totalValence = selectedElements.reduce((sum, el) => sum + el.valence, 0);
        $('#total-valence').text(totalValence);
    });

    // (Opcional) Função de busca para moléculas (se necessário)
    $('#search').click(function() {
        const formula = $('#search-formula').val();
        document.getElementById('search').disabled = true;
        document.getElementById('search').textContent = 'Buscando...';

        $.ajax({
            type: 'POST',
            url: '/search',
            contentType: 'application/json',
            data: JSON.stringify({ formula: formula }),
            success: function(response) {
                if (response.success) {
                    $('#search-result').html(`
                        <div class="alert alert-success d-flex flex-grow-1">
                            Formula: ${response.data.form} <br>
                            CID: ${response.data.cid} <br>
                            Peso Molecular: ${response.data.peso}<br>
                            Nome IUPAC: ${response.data.iupac}<br>
                            Sinonimo:${response.data.sinonimo[0]} <br>
                            <img class="rounded float-left" src='https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${response.data.cid}/PNG'><br>

                        </div>
                    `);
                } else {
                    $('#search-result').html(`
                        <div class="alert alert-danger">${response.message}</div>
                    `);
                }
                document.getElementById('search').disabled = false;
                document.getElementById('search').textContent = 'Buscar';
            },
            error: function() {
                $('#search-result').html(`
                    <div class="alert alert-danger">Erro ao buscar a molécula.</div>
                `);
                document.getElementById('search').disabled = false;
                document.getElementById('search').textContent = 'Buscar';
            }
        });
    });
});
